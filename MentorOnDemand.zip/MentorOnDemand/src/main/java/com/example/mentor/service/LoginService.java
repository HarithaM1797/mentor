package com.example.mentor.service;

import java.sql.SQLException;
import java.util.List;

import com.example.mentor.model.Login;
import com.example.mentor.model.Login;
public interface LoginService {



	public List<Login> getAllUserDetails() throws SQLException;
	 

}
