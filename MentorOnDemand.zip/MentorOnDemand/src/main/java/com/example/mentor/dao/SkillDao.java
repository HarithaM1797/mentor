package com.example.mentor.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.mentor.model.Skill;



public interface SkillDao extends JpaRepository<Skill, Integer> {


}
