   package com.example.mentor.controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.mentor.dao.MentorDao;
import com.example.mentor.dao.SkillDao;
import com.example.mentor.dao.UserDao;
import com.example.mentor.model.Login;
import com.example.mentor.model.Mentor;
import com.example.mentor.model.Skill;
import com.example.mentor.model.User;
import com.example.mentor.service.MentorService;
import com.example.mentor.service.SkillService;
import com.example.mentor.service.UserService;

@Controller
public class AdminController {

	  @Autowired
	     SkillService skillService;
	  
	  @Autowired
	     MentorService mentorService;
	  
	  @Autowired
	     UserService userService;
	  
	  @Autowired
	  	SkillDao skillDao;
	  
	  @Autowired
	  	MentorDao mentorDao;
	  
	  @Autowired
	  	UserDao userDao;
	  
	  
	   @RequestMapping(path="/addSkill")
	     public ModelAndView register() throws Exception {
	           ModelAndView mv=new ModelAndView();
	           mv.setViewName("AddSkill");
	           return mv;
	     }
	     @RequestMapping(path="/updateSkill",method = RequestMethod.POST)    
	     public String insertCompany(Skill skill) throws SQLException{
	       try {
	             skillService.insertSkill(skill);
	        
	       }
	       catch(Exception e)
	       {
	             e.printStackTrace();
	       }
	           return "AdminLanding";
	             
	       }
	     
	     
	     
	     @RequestMapping(path="/fetchtechnologies", method = { RequestMethod.POST, RequestMethod.GET } )
	      public ModelAndView fetchtechnologies(ModelMap model, HttpServletRequest request)
	      {
	         ModelAndView mav = null;
	         
	                List<Skill> skills = null;
	                
	                HttpSession session = request.getSession(false);
	                
	         skills = skillService.getAlltechnology();
	         
	         session.setAttribute("skills",skills);
	         System.out.println(skills);
	    
	         mav = new ModelAndView("ListTraining");
	         
	         return mav;
	      }
	     @RequestMapping(path="/fetchmentors", method = { RequestMethod.POST, RequestMethod.GET } )
	      public ModelAndView fetchmentors(ModelMap model, HttpServletRequest request) throws SQLException
	      {
	         ModelAndView mav = null;
	         
	                List<Mentor> mentors = null;
	                
	                HttpSession session = request.getSession(false);
	                
	        mentors = mentorService.getAllmentors();
	         
	         session.setAttribute("mentors",mentors);
	         System.out.println(mentors);
	    
	         mav = new ModelAndView("ListMentor");
	         
	         return mav;
	      }
	     @RequestMapping(path="/fetchusers", method = { RequestMethod.POST, RequestMethod.GET } )
	      public ModelAndView fetchusers(ModelMap model, HttpServletRequest request)
	      {
	         ModelAndView mav = null;
	         
	                List<User> users = null;
	                
	                HttpSession session = request.getSession(false);
	                
	        users = userService.getAllusers();
	         
	         session.setAttribute("users",users);
	         System.out.println(users);
	    
	         mav = new ModelAndView("ListUser");
	         
	         return mav;
	      }
	     }


	  

