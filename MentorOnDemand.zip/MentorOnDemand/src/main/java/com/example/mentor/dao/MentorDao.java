package com.example.mentor.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.mentor.model.Mentor;
import com.example.mentor.model.User;

public interface MentorDao extends JpaRepository<Mentor, Integer>{

	public List<Mentor>  findBySkills(String Skill);
    public Mentor findByEmail(String email);
}
