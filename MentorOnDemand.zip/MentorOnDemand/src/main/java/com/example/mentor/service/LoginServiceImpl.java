package com.example.mentor.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.mentor.dao.LoginDao;

import com.example.mentor.model.Login;
@Service
public class LoginServiceImpl implements LoginService {


	@Autowired
	private LoginDao loginDao;


	@Override
	public List<Login> getAllUserDetails() throws SQLException {
		// TODO Auto-generated method stub
		return loginDao.findAll();
	}


}
