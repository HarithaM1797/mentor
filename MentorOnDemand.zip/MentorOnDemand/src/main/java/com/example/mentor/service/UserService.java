package com.example.mentor.service;

import java.sql.SQLException;
import java.util.List;

import com.example.mentor.model.User;

public interface UserService {
	     public User insertUser(User user) throws SQLException;
	     public List<User> getUser() throws SQLException ;
	     public User getUserId(String email) throws SQLException;
	     public List<User> getAllusers() ;
	     public User registerCourse(User user) throws SQLException;
	 
	}



