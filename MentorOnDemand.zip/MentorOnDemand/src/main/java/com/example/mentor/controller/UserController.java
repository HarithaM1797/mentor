package com.example.mentor.controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.mentor.dao.LoginDao;
import com.example.mentor.dao.UserDao;
import com.example.mentor.model.Login;
import com.example.mentor.model.Mentor;
import com.example.mentor.model.User;
import com.example.mentor.service.MentorService;
import com.example.mentor.service.UserService;

@Controller
public class UserController {
     
     @Autowired
     UserService userService;
     
     @Autowired
     MentorService mentorService;
     
     @Autowired
     LoginDao loginDao;
     
     @Autowired
     UserDao userDao;
     
     @RequestMapping(path="/registerUser")
     public ModelAndView register() throws Exception {
           ModelAndView mv=new ModelAndView();
           mv.setViewName("UserRegistration");
           return mv;
     }
     @RequestMapping(path="/insertUser",method = RequestMethod.POST)    
     public String insertCompany(User user) throws SQLException{
       try {
             userService.insertUser(user);
             loginDao.save(new Login(user));
        
       }
       catch(Exception e)
       {
             e.printStackTrace();
       }
           return "Login";
             
       }
     @RequestMapping(path="/availablementors", method = { RequestMethod.POST, RequestMethod.GET } )
     public ModelAndView fetchmentors(ModelMap model, HttpServletRequest request) throws SQLException
     {
        ModelAndView mav = null;
       
               HttpSession session = request.getSession(false);
               
     List<Mentor>  mentor = mentorService.getAllmentors();
        
        session.setAttribute("mentor",mentor);

   
        mav = new ModelAndView("CoursesAndMentors");
        
        return mav;
     }
     
     @RequestMapping(path="/trainingSearch",method = RequestMethod.GET)    
     public ModelAndView trainingSearch(@RequestParam("search") String skill,HttpServletRequest request,ModelAndView mav) throws SQLException{
           HttpSession session = request.getSession(false);
       try {
           
         List<Mentor> mentors =  mentorService.findTrainingSkill(skill);
         mav.addObject("mentors", mentors);
           mav.setViewName("SearchCourse");

       }
       catch(Exception e)
       {
             mav.setViewName("Login");
             e.printStackTrace();
       }
           return mav;
             
       }




   
}