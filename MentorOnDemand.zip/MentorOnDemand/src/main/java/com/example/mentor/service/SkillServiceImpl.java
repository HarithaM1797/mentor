package com.example.mentor.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.mentor.dao.MentorDao;
import com.example.mentor.dao.SkillDao;
import com.example.mentor.model.Skill;

@Service
public class SkillServiceImpl implements SkillService {


    @Autowired
    private SkillDao skillDao;
    
    @Override
	public  Skill insertSkill(Skill skill) throws SQLException{
		  return skillDao.save(skill);
	}
    @Override
	public List<Skill> getAlltechnology() 
    {
                  return skillDao.findAll();
    }

	
}
