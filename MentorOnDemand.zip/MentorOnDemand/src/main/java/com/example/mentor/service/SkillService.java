package com.example.mentor.service;

import java.sql.SQLException;
import java.util.List;

import com.example.mentor.model.Skill;

public interface SkillService {

	public  Skill insertSkill(Skill skill) throws SQLException;

	 List<Skill> getAlltechnology() ;
}
