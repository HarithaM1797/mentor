package com.example.mentor.controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.mentor.dao.LoginDao;
import com.example.mentor.model.Login;
import com.example.mentor.model.Mentor;
import com.example.mentor.model.User;
import com.example.mentor.service.LoginService;
import com.example.mentor.service.MentorService;
import com.example.mentor.service.UserService;


@Controller
public class LoginController {
     @Autowired
     private LoginService loginService;
     
     @Autowired
     private UserService userService;
     
     
     @Autowired
     private MentorService mentorService;
     
     @Autowired
     LoginDao loginDao;
     
     @RequestMapping(path="/")
     public ModelAndView login() throws Exception {
           ModelAndView mv=new ModelAndView();
           mv.setViewName("Login");
           return mv;
     }
     
     @RequestMapping(value="/login" ,method = RequestMethod.GET)
     public String getLoginDetails(Login login,HttpServletRequest request) throws SQLException {
     
      String  email=login.getEmail();
     String  password=login.getPassword();
     
      Login logins = loginDao.findByEmail(email);
     System.out.println(logins);
     if(logins.getRole().equals("admin") && logins.getPassword().equals(password))
     {
       return "AdminLanding";
     }
     else if(logins.getRole().equals("user") && logins.getPassword().equals(password))
     {
       String emails= logins.getEmail();
       User user = userService.getUserId(emails);
       int userId=(int) user.getUserId();
       
       HttpSession session = request.getSession(); 
       session.setAttribute("userId",userId);
       return "UserLanding";
     }
     else if(logins.getRole().equals("mentor") && logins.getPassword().equals(password))
     {
       String emails= logins.getEmail();
      
	Mentor mentor = mentorService.getMentorId(emails);
       int userId=(int) mentor.getMentorId();
       
       HttpSession session = request.getSession(); 
       session.setAttribute("userId",userId);
       return "MentorLanding";
     }
     else 
       return "Login";
       
      
      
     }
}