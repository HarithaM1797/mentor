package com.example.mentor.service;

import java.sql.SQLException;
import java.util.List;

import com.example.mentor.model.Mentor;
import com.example.mentor.model.User;

public interface MentorService {
	  public Mentor insertMentor(Mentor mentor) throws SQLException;
	  public List<Mentor> getMentor() throws SQLException ;
	  public Mentor getMentorId(String email) throws SQLException;
	 public  List<Mentor> getAllmentors() throws SQLException;
	  public List<Mentor> findTrainingSkill(String skill)throws SQLException;
}
